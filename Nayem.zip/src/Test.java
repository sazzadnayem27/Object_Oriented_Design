import java.util.Scanner;

public class Test {


    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("   ||>> Login Your E-Wallet <<||   ");

        System.out.println("Enter the Account Number: ");
        int name = sc.nextInt();
        System.out.println("Enter the Password: ");
        String customerId = sc.next();
        Bank b1 = new Bank();
        b1.setname(12345);
        b1.setPass("Nayem");
        String x = b1.getPass();
        int s =x.compareTo(customerId);
      //  if(name==12345 && s==0) {

            e_wallet obj1=new e_wallet(name,customerId);
            obj1.menu();
       // }

    }
}

class e_wallet {
    double bal;
    double prevTrans;
    String customerName;
    String customerId;

    e_wallet(int customerName, String customerId){
        this.customerName= String.valueOf(customerName);
        this.customerId=customerId;
    }


    void deposit(double amount){
        if(amount!=0){
            bal+=amount;
            prevTrans=amount;
        }
    }

    void withdraw(double amt){
        if(amt!=0 && bal>=amt){
            bal-=amt;
            prevTrans=-amt;
        }
        else if(bal<amt){
            System.out.println("Bank balance insufficient");
        }
    }

    void getPreviousTrans(){
        if(prevTrans>0){
            System.out.println("Deposited: "+prevTrans);
        }
        else if(prevTrans<0){
            System.out.println("Withdrawn: "+Math.abs(prevTrans));
        }
        else{
            System.out.println("No transaction occured");
        }
    }

    void menu(){
        char option;
        Scanner sc=new Scanner(System.in);
        System.out.println("\n");
        System.out.println("  ||> >Welcome To Your E-Wallet Profile <<|| ");

        System.out.println("\n");
        System.out.println("     a) Check Balance");
        System.out.println("     b) Deposit Money");
        System.out.println("     c) Withdraw Money");
        System.out.println("     d) Previous Transaction");
        System.out.println("     e) Exit");

        do{
            System.out.println("********************************************");
            System.out.println("Choose an option");
            option=sc.next().charAt(0);
            System.out.println("\n");

            switch (option){
                case 'a':
                    System.out.println("......................");
                    System.out.println("Balance ="+bal);
                    System.out.println("......................");
                    System.out.println("\n");
                    break;
                case 'b':
                    System.out.println("......................");

                    System.out.print("Enter Card Number :");
                    Scanner myObj = new Scanner(System.in);
                    int age = myObj.nextInt();


                    System.out.print("Enter The Deposit Money :" );

                    double amt=sc.nextDouble();
                    System.out.println("......................");

                    deposit(amt);
                    System.out.println("\n");
                    break;
                case 'c':
                    System.out.println("......................");

                    System.out.print("Enter Card/Bank Number :");
                    Scanner myOb = new Scanner(System.in);
                    int go = myOb.nextInt();


                    System.out.print("Enter The Withdraw Money :");

                    double amtW=sc.nextDouble();
                    System.out.println("......................");

                    withdraw(amtW);
                    System.out.println("\n");
                    break;

                case 'd':
                    System.out.println("......................");
                    System.out.println("Previous Transaction:");
                    getPreviousTrans();
                    System.out.println("......................");
                    System.out.println("\n");
                    break;

                case 'e':
                    System.out.println("......................");
                    break;
                default:
                    System.out.println("Choose a correct option to proceed");
                    break;
            }

        }while(option!='e');

        System.out.println("Thank you for using our e_wallet services");
    }

}