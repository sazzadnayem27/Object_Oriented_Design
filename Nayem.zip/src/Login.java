public class Login {
    private int name;
    private String CustomerID;

    public int getName() {
        return name;
    }

    public void setName(int name) {
        this.name = name;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String customerID) {
        CustomerID = customerID;
    }

    public void setPass(String nayem) {
    }
}
