public class Bank extends Login {

    public void menu() {
    }

    public void setname(int i) {
    }

    public String getPass() {
        return null;
    }
}
